<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
<link rel="stylesheet" href="../assets/css/bootstrap.css">
<link rel="stylesheet" href="../assets/css/bootstrap-grid.min.css">
<link rel="stylesheet" href="../assets/css/bootstrap-grid.css">
<link rel="stylesheet" href="../assets/css/bootstrap-reboot.css">
<link rel="stylesheet" href="../assets/css/datatables.min.css">
<link rel="stylesheet" href="../assets/css/twitter-bootstrap.css">
<link rel="stylesheet" href="../assets/css/bootstrap-select.min.css">


<!-- Bootstrap JS Links -->
<script src="../assets/js/jquery-3.4.1.slim.js"></script>
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/popper.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/bootstrap.js"></script>
<script src="../assets/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/bootstrap-select.min.js"></script>
<script src="../assets/js/datatables.min.js"></script>



<!-- Data Table Links -->
<!--
<script src="../assets/js/jquery-3.3.1.js"></script>
<script src="../assets/js/jquery.dataTables.min.js"></script>
<script src="../assets/js/dataTables.bootstrap4.min.js"></script>
-->
<!--
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>

-->
