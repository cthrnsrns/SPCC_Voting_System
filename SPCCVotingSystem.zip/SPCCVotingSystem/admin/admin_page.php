<?php

//Include authentication
require("process/auth.php");

?>


<?php 
include('sidebar.php');
?>
<!DOCTYPE HTML>
<html lang="en-US">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrator Login</title>
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/welcome.css">
    
</head>
<body id="page-top">

<!-- Header -->
<!-- End Header -->



  <header class="masthead">
    <div class="container">
      <div class="intro-text">
        <div class="intro-lead-in">Welcome to Our Voting System!</div>
        <div class="intro-heading text-uppercase">Systems Plus Computer College</div>
        <br><br>
        <div class="contactUs">Contact Us
        <div class="small"><!--Direct - 336-5689 | Local - 2221--></div>
        </div>
      </div>
    </div>
  </header>


<script src="../assets/js/jquery.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>

</body>
</html>